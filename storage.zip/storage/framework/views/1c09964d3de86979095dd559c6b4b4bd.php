<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.doctor.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.doctors.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.phone')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->phone); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.designation')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->designation->title ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.gender')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Doctor::GENDER_RADIO[$doctor->gender] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.specialist')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $doctor->specialists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $specialist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($specialist->title); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.hospital')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $doctor->hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($hospital->title); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.day')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $doctor->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($day->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.address')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.short_details')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->short_details); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.overview')); ?>

                        </th>
                        <td>
                            <?php echo $doctor->overview; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.pro_image')); ?>

                        </th>
                        <td>
                            <?php if($doctor->pro_image): ?>
                                <a href="<?php echo e($doctor->pro_image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($doctor->pro_image->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.fee')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->fee); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctor.fields.old_fee')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->old_fee); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.doctors.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#doctor_doctor_serials" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.doctorSerial.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#doctor_appointments" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.appointment.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="doctor_doctor_serials">
            <?php if ($__env->exists('admin.doctors.relationships.doctorDoctorSerials', ['doctorSerials' => $doctor->doctorDoctorSerials])) echo $__env->make('admin.doctors.relationships.doctorDoctorSerials', ['doctorSerials' => $doctor->doctorDoctorSerials], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="doctor_appointments">
            <?php if ($__env->exists('admin.doctors.relationships.doctorAppointments', ['appointments' => $doctor->doctorAppointments])) echo $__env->make('admin.doctors.relationships.doctorAppointments', ['appointments' => $doctor->doctorAppointments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\saiful\other\Appointment\resources\views/admin/doctors/show.blade.php ENDPATH**/ ?>