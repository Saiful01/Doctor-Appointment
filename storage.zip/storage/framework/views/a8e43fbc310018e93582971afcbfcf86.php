<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/todays-appointments*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/appointments*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/appointment-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/appointment-reports*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw far fa-calendar-alt c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.appointmentManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('todays_appointment_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.todays-appointments.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/todays-appointments") || request()->is("admin/todays-appointments/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar-check c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.todaysAppointment.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.appointments.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/appointments") || request()->is("admin/appointments/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.appointment.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_status_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.appointment-statuses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/appointment-statuses") || request()->is("admin/appointment-statuses/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.appointmentStatus.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_report_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.appointment-reports.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/appointment-reports") || request()->is("admin/appointment-reports/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file-prescription c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.appointmentReport.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/doctors*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/doctor-serials*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-user-md c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.doctorManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.doctors.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/doctors") || request()->is("admin/doctors/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-md c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.doctor.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_serial_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.doctor-serials.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/doctor-serials") || request()->is("admin/doctor-serials/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw far fa-calendar-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.doctorSerial.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('patient_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/applicants*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/guest-patients*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-female c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.patientManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicant_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.applicants.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/applicants") || request()->is("admin/applicants/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.applicant.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('guest_patient_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.guest-patients.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/guest-patients") || request()->is("admin/guest-patients/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-ninja c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.guestPatient.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hospital_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.hospitals.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/hospitals") || request()->is("admin/hospitals/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-home c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.hospital.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('status_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.statuses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/statuses") || request()->is("admin/statuses/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-signal c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.status.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('specialist_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.specialists.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/specialists") || request()->is("admin/specialists/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-address-book c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.specialist.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('weekly_day_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.weekly-days.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/weekly-days") || request()->is("admin/weekly-days/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-calendar-alt c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.weeklyDay.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-bell c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userAlert.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('blog_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.blogs.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/blogs") || request()->is("admin/blogs/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fab fa-blogger-b c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.blog.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('platform_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.platforms.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/platforms") || request()->is("admin/platforms/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-home c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.platform.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('designation_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.designations.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/designations") || request()->is("admin/designations/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-pen-alt c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.designation.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.galleries.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/galleries") || request()->is("admin/galleries/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw far fa-images c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.gallery.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('location_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/divisions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/districts*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/upazilas*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-map-marker-alt c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.location.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('division_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.divisions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/divisions") || request()->is("admin/divisions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-globe-africa c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.division.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('district_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.districts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/districts") || request()->is("admin/districts/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-map-marked c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.district.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('upazila_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.upazilas.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/upazilas") || request()->is("admin/upazilas/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-map-marked c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.upazila.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/faq-categories*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/faq-questions*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-question c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.faqManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_category_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.faq-categories.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/faq-categories") || request()->is("admin/faq-categories/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.faqCategory.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq_question_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.faq-questions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/faq-questions") || request()->is("admin/faq-questions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-question c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.faqQuestion.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('video_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.videos.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/videos") || request()->is("admin/videos/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fab fa-youtube c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.video.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "c-active" : ""); ?> c-sidebar-nav-link">
                    <i class="c-sidebar-nav-icon fa-fw fa fa-envelope">

                    </i>
                    <span><?php echo e(trans('global.messages')); ?></span>
                    <?php if($unread > 0): ?>
                        <strong>( <?php echo e($unread); ?> )</strong>
                    <?php endif; ?>

                </a>
            </li>
            <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="c-sidebar-nav-item">
                        <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(trans('global.change_password')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="c-sidebar-nav-item">
                <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
    </ul>

</div><?php /**PATH E:\saiful\other\Appointment\resources\views/partials/menu.blade.php ENDPATH**/ ?>